<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Send email in PHP</title>
<meta name="robots" content="noindex, nofollow">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount', 'UA-43981329-1']);
	_gaq.push(['_trackPageview']);
	(function() {
	var ga = document.createElement('script');
	ga.type = 'text/javascript';
	ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0];
	s.parentNode.insertBefore(ga, s);
	})();
</script>

</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">PHPMailer To Sent Mail</a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">Action</a></li>
      <li><a href="#">Demo</a></li>
      <li><a href="#">Contact</a></li>
    </ul>
  </div>
</nav>
<div class="container-fluid">  
  <div class="row">
    <div class="col-sm-6 col-sm-offset-3" style="">
		<form action="index.php" method="post">
		   <div class="form-group">
				<label for="email">Email address:</label>				
				<input type="email" class="form-control" id="email" placeholder="FROM : Enter your email ID" name="email" required="required"/>
		   </div>
		   <div class="form-group">
				<label for="password">Password:</label>				
				<input type="password" class="form-control" id="password" placeholder="**************" name="password" required="required"/>
		   </div>
		   <div class="form-group">
				<label for="toid">Email address:</label>				
				<input type="email" class="form-control" id="toid" placeholder="TO : " name="toid" required="required"/>
		   </div>
		   <div class="form-group">
				<label for="subject">Email address:</label>				
				<input type="text" class="form-control" id="subject" placeholder="Subject" name="subject" required="required"/>
		   </div>
		   <div class="form-group">
				<label for="message">Message:</label>				
				<textarea rows="4" cols="50" placeholder="Enter Your Message..." class="form-control" name="message" required="required"></textarea>
		   </div>
		   <div class="form-group" align="right">				
				<input type="submit" class="btn btn-primary" value="Send" name="send"/>	
		   </div>
		</form>
	</div>    
  </div>
</div>

<?php
require 'PHPMailerAutoload.php';
if(isset($_POST['send']))
{
$email = $_POST['email'];
$password = $_POST['password'];
$to_id = $_POST['toid'];
$message = $_POST['message'];
$subject = $_POST['subject'];
$mail = new PHPMailer;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = $email;
$mail->Password = $password;
$mail->addAddress($to_id);
$mail->Subject = $subject;
$mail->msgHTML($message);
if (!$mail->send()) {
$error = "Mailer Error: " . $mail->ErrorInfo;
echo '<p id="para">'.$error.'</p>';
}
else {
echo '
<script> alert("Message Sent Successfully..Check Your Mail"); </script>
';
}
}

?>
</body>
</html>